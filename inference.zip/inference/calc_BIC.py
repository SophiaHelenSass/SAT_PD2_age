"""
@author: Lorenz Goenner
"""

import numpy as np

def calc_BIC(inferrer, responses, conditions, m_prob, n_actions_considered = 1):
    # Evaluate (log-)likelihood of actual choices, given the inferred model parameters:    
    n_subj = len(responses)
    n_miniblocks = responses.shape[1]
    nll_firstaction_mean = np.nan * np.ones([n_subj, n_miniblocks])    
    nll_firstaction_depths = np.nan * np.ones([n_subj, n_miniblocks, 3])

    nll_hinoise_all = np.nan * np.ones([n_subj, 3])
    nll_lonoise_all = np.nan * np.ones([n_subj, 3])
    nll_all = np.nan * np.ones([n_subj, 3])

    nll_hinoise_120 = np.nan * np.ones([n_subj, 3])
    nll_lonoise_120 = np.nan * np.ones([n_subj, 3])
    nll_120 = np.nan * np.ones([n_subj, 3])

    nll_hinoise_120_mean = np.nan * np.ones([n_subj])
    nll_lonoise_120_mean = np.nan * np.ones([n_subj])
    nll_120_mean = np.nan * np.ones([n_subj])

    pseudo_rsquare_120_mean = np.nan * np.ones([n_subj])
    pseudo_rsquare_hinoise_120_mean = np.nan * np.ones([n_subj])
    pseudo_rsquare_lonoise_120_mean = np.nan * np.ones([n_subj])

    m_param_count = inferrer.agent.np
    BIC_120_mean = np.nan * np.ones([n_subj])
    BIC_hinoise_120 = np.nan * np.ones([n_subj])
    BIC_lonoise_120 = np.nan * np.ones([n_subj])


    for i_mblk in range(n_miniblocks):
        for i_action in range(n_actions_considered): # Consider only first action; use range(3) to consider all action steps
            logits_depths = inferrer.agent.logits[3*i_mblk + i_action].detach().numpy() 
            for i_subj in range(n_subj):
                resp = inferrer.responses[i_subj][i_mblk].numpy()[i_action] 
                
                #The logits haven't been transformed into probabilities yet.--> softmax function for choice probabilities
                p_jump_depths = 1.0 / (1 + np.exp(-logits_depths[i_subj])) 
                p_move_depths = 1 - p_jump_depths
                
                if resp==1:
                    nll = -np.log(p_jump_depths) # obtain the negative log-likelihood (nll), for numerical reasons
                elif resp==0:
                    nll = -np.log(p_move_depths)        
                      
                nll_firstaction_depths[i_subj, i_mblk, :] = nll              
                nll_firstaction_mean[i_subj, i_mblk] = np.matmul(nll_firstaction_depths[i_subj, i_mblk, :], 
                                                                 m_prob[0][i_mblk, i_subj, :])            

                nll_hinoise_all[i_subj, :] = np.matmul(nll_firstaction_depths[i_subj, :, :].transpose(), 
                                                       conditions[0][i_subj, :].numpy()) # Sum of NLL for high noise (noise==1) 
                nll_lonoise_all[i_subj, :] = np.matmul(nll_firstaction_depths[i_subj, :, :].transpose(), 
                                                       1 - conditions[0][i_subj, :].numpy()) # Sum of NLL for low noise (noise==0)
                nll_all[i_subj, :] = nll_hinoise_all[i_subj, :] + nll_lonoise_all[i_subj, :]
                
                nll_hinoise_120[i_subj, :] = np.matmul(nll_firstaction_depths[i_subj, 20:, :].transpose(), conditions[0][i_subj, 20:].numpy()) # Exclude 20 training miniblocks
                nll_lonoise_120[i_subj, :] = np.matmul(nll_firstaction_depths[i_subj, 20:, :].transpose(), 1 - conditions[0][i_subj, 20:].numpy()) 
                nll_120[i_subj, :] = nll_hinoise_120[i_subj, :] + nll_lonoise_120[i_subj, :]

                nll_hinoise_120_mean[i_subj] = np.matmul(nll_firstaction_mean[i_subj, 20:].transpose(), conditions[0][i_subj, 20:].numpy()) # Exclude 20 training miniblocks
                nll_lonoise_120_mean[i_subj] = np.matmul(nll_firstaction_mean[i_subj, 20:].transpose(), 1 - conditions[0][i_subj, 20:].numpy()) 
                nll_120_mean[i_subj] = nll_hinoise_120_mean[i_subj] + nll_lonoise_120_mean[i_subj]

                nll_random_120 = -np.log(0.5)*120 * n_actions_considered
                nll_random_60 = -np.log(0.5)*60 * n_actions_considered    
                pseudo_rsquare_120_mean[i_subj] = 1 - (nll_120_mean[i_subj] / nll_random_120)
                pseudo_rsquare_hinoise_120_mean[i_subj] = 1 - (nll_hinoise_120_mean[i_subj] / nll_random_60)    
                pseudo_rsquare_lonoise_120_mean[i_subj] = 1 - (nll_lonoise_120_mean[i_subj] / nll_random_60)        

                BIC_120_mean[i_subj] = 2*nll_120_mean[i_subj] + m_param_count*np.log(120 * n_actions_considered)
                BIC_hinoise_120[i_subj] = 2*nll_hinoise_120_mean[i_subj] + m_param_count*np.log(60 * n_actions_considered)
                BIC_lonoise_120[i_subj] = 2*nll_lonoise_120_mean[i_subj] + m_param_count*np.log(60 * n_actions_considered)    
                
    return nll_120_mean, nll_hinoise_120_mean, nll_lonoise_120_mean, \
           pseudo_rsquare_120_mean, BIC_120_mean, \
           pseudo_rsquare_hinoise_120_mean, BIC_hinoise_120, \
           pseudo_rsquare_lonoise_120_mean, BIC_lonoise_120
           