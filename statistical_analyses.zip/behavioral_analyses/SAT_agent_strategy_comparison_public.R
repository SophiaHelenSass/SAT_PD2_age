#by Sophia-Helen Sass
#(statistical) analysis of agent's gain in the SAT PD 2.0 ####
#SIMULATED DATA#

#preparation####
#clear workspace
rm(list = ls())

# install.packages("car");
# install.packages("ggplot2")
# install.packages("psych")
# install.packages("rstatix")
# install.packages("tidyverse")
# install.packages("ggpubr")
# install.packages("reshape")
# install.packages("dplyr")
# install.packages("plyr")
# install.packages("plotrix")

library(car)
library(ggplot2)
library(psych)
library(tidyverse)
library(ggpubr)
library(rstatix)
library(dplyr)
library(reshape)
library(plyr)
library(ggsignif)
library(plotrix)

#load noise condition factor
setwd("your directory")
#load most recent data version here
cond<- read.csv("conditions.csv", header = TRUE)

#load agent data
#set working and data directory
setwd("your directory")

#####rational agent#######
#beta = 3, alpha = 0.1, theta = 0
rational_agent_all<- read.csv("miniblock_gain_mean_std_rational_1000.csv", header = TRUE)

rational_agent <- rational_agent_all[ ,-c(4:7)]
names(rational_agent)[names(rational_agent) == 'Mean_gain_PD3'] <- 'Gain'
rational_agent$noise_condition<-cond

rational_agent_PD2 <- rational_agent_all[ ,-c(2,3,6,7)]
names(rational_agent_PD2)[names(rational_agent_PD2) == 'Mean_gain_PD2'] <- 'Gain'
rational_agent_PD2$noise_condition<-cond

rational_agent_PD1 <- rational_agent_all[ ,-c(2,3,4,5)]
names(rational_agent_PD1)[names(rational_agent_PD1) == 'Mean_gain_PD1'] <- 'Gain'
rational_agent_PD1$noise_condition<-cond

#PD3
rational_agentgainhigh<- sum(rational_agent$Gain[rational_agent$noise_condition == "high"])
rational_agentgainlow<- sum(rational_agent$Gain[rational_agent$noise_condition == "low"])
se_rational_agentgainhigh<- std.error(rational_agent$Gain[rational_agent$noise_condition == "high"])
se_rational_agentgainlow<- std.error(rational_agent$Gain[rational_agent$noise_condition == "low"])
rational_agentgainsum <- sum(rational_agent$Gain)

#PD2
rational_agent_PD2gainhigh<- sum(rational_agent_PD2$Gain[rational_agent_PD2$noise_condition == "high"])
rational_agent_PD2gainlow<- sum(rational_agent_PD2$Gain[rational_agent_PD2$noise_condition == "low"])
se_rational_agent_PD2gainhigh<- std.error(rational_agent_PD2$Gain[rational_agent_PD2$noise_condition == "high"])
se_rational_agent_PD2gainlow<- std.error(rational_agent_PD2$Gain[rational_agent_PD2$noise_condition == "low"])
rational_agent_PD2gainsum <- sum(rational_agent_PD2$Gain)

#PD1
rational_agent_PD1gainhigh<- sum(rational_agent_PD1$Gain[rational_agent_PD1$noise_condition == "high"])
rational_agent_PD1gainlow<- sum(rational_agent_PD1$Gain[rational_agent_PD1$noise_condition == "low"])
se_rational_agent_PD1gainhigh<- std.error(rational_agent_PD1$Gain[rational_agent_PD1$noise_condition == "high"])
se_rational_agent_PD1gainlow<- std.error(rational_agent_PD1$Gain[rational_agent_PD1$noise_condition == "low"])
rational_agent_PD1gainsum <- sum(rational_agent_PD1$Gain)

#####random agent########
#beta = 0, alpha = 0.1, theta = 0
random_agent<- read.csv("miniblock_gain_mean_std_random_1000.csv", header = TRUE)
random_agent <- random_agent[ ,-c(4:7)]
names(random_agent)[names(random_agent) == 'Mean_gain_PD3'] <- 'Gain'
random_agent$noise_condition<-cond

random_agentgainhigh<- sum(random_agent$Gain[random_agent$noise_condition == "high"])
random_agentgainlow<- sum(random_agent$Gain[random_agent$noise_condition == "low"])
se_random_agentgainhigh<- std.error(random_agent$Gain[random_agent$noise_condition == "high"])
se_random_agentgainlow<- std.error(random_agent$Gain[random_agent$noise_condition == "low"])
random_agentgainsum <- sum(random_agent$Gain)


#####discount + full-breadth planning agent ####
#beta = 3, theta = 0, kappa = 10
disc_1_agent_all<- read.csv("miniblock_gain_mean_std_discount_hyperbolic_theta_alpha_k3.0_1000.csv", header = TRUE)
disc_1_agent <- disc_1_agent_all[ ,-c(4:7)]
names(disc_1_agent)[names(disc_1_agent) == 'Mean_gain_PD3'] <- 'Gain'
disc_1_agent$noise_condition<-cond

#PD3
disc_1_agentgainhigh<- sum(disc_1_agent$Gain[disc_1_agent$noise_condition == "high"])
disc_1_agentgainlow<- sum(disc_1_agent$Gain[disc_1_agent$noise_condition == "low"])
se_disc_1_agentgainhigh<- std.error(disc_1_agent$Gain[disc_1_agent$noise_condition == "high"])
se_disc_1_agentgainlow<- std.error(disc_1_agent$Gain[disc_1_agent$noise_condition == "low"])
disc_1_agentgainsum <- sum(disc_1_agent$Gain)

#PD2
disc_1_agent_PD2 <- disc_1_agent_all[ ,-c(2,3,6,7)]
names(disc_1_agent_PD2)[names(disc_1_agent_PD2) == 'Mean_gain_PD2'] <- 'Gain'
disc_1_agent_PD2$noise_condition<-cond

disc_1_agent_PD2gainhigh<- sum(disc_1_agent_PD2$Gain[disc_1_agent_PD2$noise_condition == "high"])
disc_1_agent_PD2gainlow<- sum(disc_1_agent_PD2$Gain[disc_1_agent_PD2$noise_condition == "low"])
se_disc_1_agent_PD2gainhigh<- std.error(disc_1_agent_PD2$Gain[disc_1_agent_PD2$noise_condition == "high"])
se_disc_1_agent_PD2gainlow<- std.error(disc_1_agent_PD2$Gain[disc_1_agent_PD2$noise_condition == "low"])
disc_1_agent_PD2gainsum <- sum(disc_1_agent_PD2$Gain)

#PD1
disc_1_agent_PD1 <- disc_1_agent_all[ ,-c(2,3,4,5)]
names(disc_1_agent_PD1)[names(disc_1_agent_PD1) == 'Mean_gain_PD1'] <- 'Gain'
disc_1_agent_PD1$noise_condition<-cond

disc_1_agent_PD1gainhigh<- sum(disc_1_agent_PD1$Gain[disc_1_agent_PD1$noise_condition == "high"])
disc_1_agent_PD1gainlow<- sum(disc_1_agent_PD1$Gain[disc_1_agent_PD1$noise_condition == "low"])
se_disc_1_agent_PD1gainhigh<- std.error(disc_1_agent_PD1$Gain[disc_1_agent_PD1$noise_condition == "high"])
se_disc_1_agent_PD1gainlow<- std.error(disc_1_agent_PD1$Gain[disc_1_agent_PD1$noise_condition == "low"])
disc_1_agent_PD1gainsum <- sum(disc_1_agent_PD1$Gain)

 
#####discount + lowprob pruning agent#####
#beta = 3, theta = 0, kappa = 10
disc_prun_1_agent_all<- read.csv("miniblock_gain_mean_std_discount_hyperbolic_theta_lowprob_pruning_k3.0_1000.csv", header = TRUE)

disc_prun_1_agent <- disc_prun_1_agent_all[ ,-c(4:7)]
names(disc_prun_1_agent)[names(disc_prun_1_agent) == 'Mean_gain_PD3'] <- 'Gain'
disc_prun_1_agent$noise_condition<-cond

#this is what agent get per mini-block summed up
disc_prun_1_agentgainhigh<- sum(disc_prun_1_agent$Gain[disc_prun_1_agent$noise_condition == "high"])
disc_prun_1_agentgainlow<- sum(disc_prun_1_agent$Gain[disc_prun_1_agent$noise_condition == "low"])
se_disc_prun_1_agentgainhigh<- std.error(disc_prun_1_agent$Gain[disc_prun_1_agent$noise_condition == "high"])
se_disc_prun_1_agentgainlow<- std.error(disc_prun_1_agent$Gain[disc_prun_1_agent$noise_condition == "low"])
disc_prun_1_agentgainsum <- sum(disc_prun_1_agent$Gain)

#PD2
disc_prun_1_agent_PD2 <- disc_prun_1_agent_all[ ,-c(2,3,6,7)]
names(disc_prun_1_agent_PD2)[names(disc_prun_1_agent_PD2) == 'Mean_gain_PD2'] <- 'Gain'
disc_prun_1_agent_PD2$noise_condition<-cond

disc_prun_1_agent_PD2gainhigh<- sum(disc_prun_1_agent_PD2$Gain[disc_prun_1_agent_PD2$noise_condition == "high"])
disc_prun_1_agent_PD2gainlow<- sum(disc_prun_1_agent_PD2$Gain[disc_prun_1_agent_PD2$noise_condition == "low"])
se_disc_prun_1_agent_PD2gainhigh<- std.error(disc_prun_1_agent_PD2$Gain[disc_prun_1_agent_PD2$noise_condition == "high"])
se_disc_prun_1_agent_PD2gainlow<- std.error(disc_prun_1_agent_PD2$Gain[disc_prun_1_agent_PD2$noise_condition == "low"])
disc_prun_1_agent_PD2gainsum <- sum(disc_prun_1_agent_PD2$Gain)


#PD1
disc_prun_1_agent_PD1 <- disc_prun_1_agent_all[ ,-c(2,3,4,5)]
names(disc_prun_1_agent_PD1)[names(disc_prun_1_agent_PD1) == 'Mean_gain_PD1'] <- 'Gain'
disc_prun_1_agent_PD1$noise_condition<-cond

disc_prun_1_agent_PD1gainhigh<- sum(disc_prun_1_agent_PD1$Gain[disc_prun_1_agent_PD1$noise_condition == "high"])
disc_prun_1_agent_PD1gainlow<- sum(disc_prun_1_agent_PD1$Gain[disc_prun_1_agent_PD1$noise_condition == "low"])
se_disc_prun_1_agent_PD1gainhigh<- std.error(disc_prun_1_agent_PD1$Gain[disc_prun_1_agent_PD1$noise_condition == "high"])
se_disc_prun_1_agent_PD1gainlow<- std.error(disc_prun_1_agent_PD1$Gain[disc_prun_1_agent_PD1$noise_condition == "low"])
disc_prun_1_agent_PD1gainsum <- sum(disc_prun_1_agent_PD1$Gain)

#####lowprob pruning agent ######
#beta = 3, theta = 0
prun_agent_all<- read.csv("miniblock_gain_mean_std_lowprob_pruning_1000.csv", header = TRUE)

prun_agent <- prun_agent_all[ ,-c(4:7)]
names(prun_agent)[names(prun_agent) == 'Mean_gain_PD3'] <- 'Gain'
prun_agent$noise_condition<-cond

prun_agentgainhigh<- sum(prun_agent$Gain[prun_agent$noise_condition == "high"])
prun_agentgainlow<- sum(prun_agent$Gain[prun_agent$noise_condition == "low"])
se_prun_agentgainhigh<- std.error(prun_agent$Gain[prun_agent$noise_condition == "high"])
se_prun_agentgainlow<- std.error(prun_agent$Gain[prun_agent$noise_condition == "low"])
prun_agentgainsum <- sum(prun_agent$Gain)

#PD2
prun_agent_PD2 <- prun_agent_all[ ,-c(2,3,6,7)]
names(prun_agent_PD2)[names(prun_agent_PD2) == 'Mean_gain_PD2'] <- 'Gain'
prun_agent_PD2$noise_condition<-cond

prun_agent_PD2gainhigh<- sum(prun_agent_PD2$Gain[prun_agent_PD2$noise_condition == "high"])
prun_agent_PD2gainlow<- sum(prun_agent_PD2$Gain[prun_agent_PD2$noise_condition == "low"])
se_prun_agent_PD2gainhigh<- std.error(prun_agent_PD2$Gain[prun_agent_PD2$noise_condition == "high"])
se_prun_agent_PD2gainlow<- std.error(prun_agent_PD2$Gain[prun_agent_PD2$noise_condition == "low"])
prun_agent_PD2gainsum <- sum(prun_agent_PD2$Gain)

#PD1
prun_agent_PD1 <- prun_agent_all[ ,-c(2,3,4,5)]
names(prun_agent_PD1)[names(prun_agent_PD1) == 'Mean_gain_PD1'] <- 'Gain'
prun_agent_PD1$noise_condition<-cond

prun_agent_PD1gainhigh<- sum(prun_agent_PD1$Gain[prun_agent_PD1$noise_condition == "high"])
prun_agent_PD1gainlow<- sum(prun_agent_PD1$Gain[prun_agent_PD1$noise_condition == "low"])
se_prun_agent_PD1gainhigh<- std.error(prun_agent_PD1$Gain[prun_agent_PD1$noise_condition == "high"])
se_prun_agent_PD1gainlow<- std.error(prun_agent_PD1$Gain[prun_agent_PD1$noise_condition == "low"])
prun_agent_PD1gainsum <- sum(prun_agent_PD1$Gain)


#build joint data frame for plotting
comp_model_gains <- ldply (rbind(random_agentgainlow, random_agentgainhigh,
                           rational_agentgainlow, rational_agentgainhigh,
                           rational_agent_PD2gainlow, rational_agent_PD2gainhigh,
                           rational_agent_PD1gainlow, rational_agent_PD1gainhigh,
                           disc_1_agentgainlow, disc_1_agentgainhigh,
                           disc_1_agent_PD2gainlow, disc_1_agent_PD2gainhigh,
                           disc_1_agent_PD1gainlow, disc_1_agent_PD1gainhigh,
                           prun_agentgainlow, prun_agentgainhigh,
                           prun_agent_PD2gainlow, prun_agent_PD2gainhigh,
                           prun_agent_PD1gainlow, prun_agent_PD1gainhigh,
                           disc_prun_1_agentgainlow, disc_prun_1_agentgainhigh,
                           disc_prun_1_agent_PD2gainlow, disc_prun_1_agent_PD2gainhigh,
                           disc_prun_1_agent_PD1gainlow, disc_prun_1_agent_PD1gainhigh))
names(comp_model_gains)[names(comp_model_gains) == 'V1'] <- 'mean_gain'
                            
comp_model_ses <- ldply (rbind( se_random_agentgainlow, se_random_agentgainhigh,
                                se_rational_agentgainlow, se_rational_agentgainhigh,
                                se_rational_agent_PD2gainlow, se_rational_agent_PD2gainhigh,
                                se_rational_agent_PD1gainlow, se_rational_agent_PD1gainhigh,
                                se_disc_1_agentgainlow, se_disc_1_agentgainhigh,
                                se_disc_1_agent_PD2gainlow, se_disc_1_agent_PD2gainhigh,
                                se_disc_1_agent_PD1gainlow, se_disc_1_agent_PD1gainhigh,
                                se_prun_agentgainlow, se_prun_agentgainhigh,
                                se_prun_agent_PD2gainlow, se_prun_agent_PD2gainhigh,
                                se_prun_agent_PD1gainlow, se_prun_agent_PD1gainhigh,
                                se_disc_prun_1_agentgainlow, se_disc_prun_1_agentgainhigh,
                                se_disc_prun_1_agent_PD2gainlow, se_disc_prun_1_agent_PD2gainhigh,
                                se_disc_prun_1_agent_PD1gainlow, se_disc_prun_1_agent_PD1gainhigh))

names(comp_model_ses)[names(comp_model_ses) == 'V1'] <- 'se'

comp_model_gains_se <- cbind(comp_model_gains,comp_model_ses) 

comp_model_gains_se[1,3] = "random"
comp_model_gains_se[2,3] = "random"

comp_model_gains_se[3,3] = "full_plan_PD3"
comp_model_gains_se[4,3] = "full_plan_PD3"
comp_model_gains_se[5,3] = "full_plan_PD2"
comp_model_gains_se[6,3] = "full_plan_PD2"
comp_model_gains_se[7,3] = "full_plan_PD1"
comp_model_gains_se[8,3] = "full_plan_PD1"

comp_model_gains_se[9,3] = "disc10_full_plan_PD3"
comp_model_gains_se[10,3] = "disc10_full_plan_PD3"
comp_model_gains_se[11,3] = "disc10_full_plan_PD2"
comp_model_gains_se[12,3] = "disc10_full_plan_PD2"
comp_model_gains_se[13,3] = "disc10_full_plan_PD1"
comp_model_gains_se[14,3] = "disc10_full_plan_PD1"

comp_model_gains_se[15,3] = "prun_PD3"
comp_model_gains_se[16,3] = "prun_PD3"
comp_model_gains_se[17,3] = "prun_PD2"
comp_model_gains_se[18,3] = "prun_PD2"
comp_model_gains_se[19,3] = "prun_PD1"
comp_model_gains_se[20,3] = "prun_PD1"

comp_model_gains_se[21,3] = "disc10_prun_PD3"
comp_model_gains_se[22,3] = "disc10_prun_PD3"
comp_model_gains_se[23,3] = "disc10_prun_PD2"
comp_model_gains_se[24,3] = "disc10_prun_PD2"
comp_model_gains_se[25,3] = "disc10_prun_PD1"
comp_model_gains_se[26,3] = "disc10_prun_PD1"



comp_model_gains_se[1,4] = "low"
comp_model_gains_se[2,4] = "high"
comp_model_gains_se[3,4] = "low"
comp_model_gains_se[4,4] = "high"
comp_model_gains_se[5,4] = "low"
comp_model_gains_se[6,4] = "high"
comp_model_gains_se[7,4] = "low"
comp_model_gains_se[8,4] = "high"
comp_model_gains_se[9,4] = "low"
comp_model_gains_se[10,4] = "high"
comp_model_gains_se[11,4] = "low"
comp_model_gains_se[12,4] = "high"
comp_model_gains_se[13,4] = "low"
comp_model_gains_se[14,4] = "high"
comp_model_gains_se[15,4] = "low"
comp_model_gains_se[16,4] = "high"
comp_model_gains_se[17,4] = "low"
comp_model_gains_se[18,4] = "high"
comp_model_gains_se[19,4] = "low"
comp_model_gains_se[20,4] = "high"
comp_model_gains_se[21,4] = "low"
comp_model_gains_se[22,4] = "high"
comp_model_gains_se[23,4] = "low"
comp_model_gains_se[24,4] = "high"
comp_model_gains_se[25,4] = "low"
comp_model_gains_se[26,4] = "high"
 

names(comp_model_gains_se)[names(comp_model_gains_se) == 'V3'] <- 'model'
names(comp_model_gains_se)[names(comp_model_gains_se) == 'V4'] <- 'noise_condition'


random_agentgainhigh<- sum(random_agent$Gain[random_agent$noise_condition== "high"])
random_agentgainlow<- sum(random_agent$Gain[random_agent$noise_condition == "low"])

rational_agentgainhigh<- sum(rational_agent$Gain[rational_agent$noise_condition == "high"])
rational_agentgainlow<- sum(rational_agent$Gain[rational_agent$noise_condition == "low"])

comp_model_gains_se$rel_gain[comp_model_gains_se$noise_condition == "high"] <-
  ((comp_model_gains_se$mean_gain[comp_model_gains_se$noise_condition == "high"] - random_agentgainhigh) /
     (rational_agentgainhigh - random_agentgainhigh)) * 100

comp_model_gains_se$rel_gain[comp_model_gains_se$noise_condition== "low"] <-
  (comp_model_gains_se$mean_gain[comp_model_gains_se$noise_condition== "low"] -
     random_agentgainlow)/(rational_agentgainlow-random_agentgainlow)*100

comp_model_gains_se$rel_gain[comp_model_gains_se$model=="random"]=0

comp_model_gains_se$noise_condition <- as.factor(comp_model_gains_se$noise_condition)
comp_model_gains_se$noise_condition  <- relevel(comp_model_gains_se$noise_condition , "low")

#order factors for plotting
order <- c("low", "high")
comp_model_gains_se$noise_condition <- factor(comp_model_gains_se$noise_condition, levels = order)
comp_model_gains_se<- comp_model_gains_se[order(comp_model_gains_se$noise_condition), ]


  color_scheme <- c(
    "random" = "#0000FF",   # blau
    "full_plan_PD3" = "#333333",  # dunkelgrau
    "full_plan_PD2" = "#333333",
    "full_plan_PD1" = "#333333",
    "disc10_full_plan_PD3" = "#CCCCCC",  # hellgrau
    "disc10_full_plan_PD2" = "#CCCCCC",
    "disc10_full_plan_PD1" = "#CCCCCC",
    "prun_PD3" = "#008000",  # dunkelgr�n
    "prun_PD2" = "#008000",
    "prun_PD1" = "#008000",
    "disc10_prun_PD3" = "#66FF66",  # hellgr�n
    "disc10_prun_PD2" = "#66FF66",
    "disc10_prun_PD1" = "#66FF66"
  )
  
# Plotting #####
####relative performance####
#Barplot with facet grid, error bars, and background lines
  ggplot(comp_model_gains_se, aes(x = factor(model, 
                                             levels = c("random", "full_plan_PD3", "full_plan_PD2", 
                                                        "full_plan_PD1", "disc10_full_plan_PD3", 
                                                        "disc10_full_plan_PD2", "disc10_full_plan_PD1", 
                                                        "prun_PD3", "prun_PD2", "prun_PD1", "disc10_prun_PD3", 
                                                        "disc10_prun_PD2", "disc10_prun_PD1")), 
                                  y = rel_gain, fill = as.factor(model), alpha = 0.5)) + 
    
    geom_hline(yintercept = seq(-20, 110, by = 10), color = "grey", linetype = "dashed", size = 0.2) +  # Add horizontal lines
    geom_bar(stat = "identity", position = position_dodge(width = 0.9), width = 0.7, color = "black") +
    #geom_errorbar(aes(ymin = rel_gain - rel_se, ymax = rel_gain + rel_se), width = 0.2, size = 0.7, position = position_dodge(width = 0.9)) +
    scale_fill_manual("Transition Uncertainty", values = color_scheme) +
    theme_light() +
    theme(axis.text = element_text(size = 12),
          axis.title = element_text(size = 12),
          legend.position = "top",
          legend.title = element_text(size = 12),
          legend.text = element_text(size = 10),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank()) +
    xlab("Model") +
    ylab("Relative Performance (%)") +
    coord_cartesian(ylim = c(-20, 110)) +
    scale_y_continuous(limits = c(-20, 110)) +
    facet_grid(. ~ noise_condition, scales = "free_x", space = "free_x", switch = "x")
  
  
  
####absolute performance ####
  ggplot(comp_model_gains_se, aes(x = factor(model, 
                                             levels = c("random", "full_plan_PD3", "full_plan_PD2", 
                                                        "full_plan_PD1", "disc10_full_plan_PD3", 
                                                        "disc10_full_plan_PD2", "disc10_full_plan_PD1", 
                                                        "prun_PD3", "prun_PD2", "prun_PD1", "disc10_prun_PD3", 
                                                        "disc10_prun_PD2", "disc10_prun_PD1")), 
                                  y = mean_gain, fill = as.factor(model), alpha = 0.5)) + 
    
    geom_hline(yintercept = seq(-200, 1300, by = 100), color = "grey", linetype = "dashed", size = 0.2) +  # Add horizontal lines
    geom_bar(stat = "identity", position = position_dodge(width = 0.9), width = 0.7, color = "black") +
    geom_errorbar(aes(ymin = mean_gain - se, ymax = mean_gain + se), width = 0.2, size = 0.7, position = position_dodge(width = 0.9)) +
    scale_fill_manual(values = color_scheme) +
    theme_light() +
    theme(axis.text = element_text(size = 12),
          axis.title = element_text(size = 12),
          legend.position = "top",
          legend.title = element_text(size = 12),
          legend.text = element_text(size = 10),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank()) +
    xlab("Model") +
    ylab("absolute Performance (points)") +
    coord_cartesian(ylim = c(-200, 1300)) +
    scale_y_continuous(limits = c(-200, 1300)) +
    facet_grid(. ~ noise_condition, scales = "free_x", space = "free_x", switch = "x")
  
  
  
#END#####