################### Statistical analysis of performance and planning time in the SAT PD 2 ####################################################
# by Sophia-Helen Sass
# using pre-processed and cleaned data 

#clear workspace
rm(list = ls())

# install.packages("car");
# install.packages("ggplot2")
# install.packages("psych")
# install.packages("rstatix")
# install.packages("tidyverse")
# install.packages("ggpubr")
# install.packages("reshape")
# install.packages("dplyr")
# install.packages("plyr")

#load packages
library(car)
library(ggplot2)
library(psych)
library(tidyverse)
library(ggpubr)
library(rstatix)
library(dplyr)
library(reshape)
library(plyr)

#set working directory and load data
setwd("your directory")
B3_SAT<- read.csv("SAT_neuro_quest_all_data.csv", header = TRUE)

#turn age group variable into factor for analyses
B3_SAT$group <- as.factor(B3_SAT$group)
#make "young adults" level 1
B3_SAT$group  <- relevel(B3_SAT$group , "young adults")

#Analyze relative performance (RP)####
SAT_RP <- subset(B3_SAT,select=c("group","participant_ID","rel_gain_high","rel_gain_low"))

#reshape data, turtn noise condition into factor 
SAT_RP <-melt.data.frame(SAT_RP, id=c("group", "participant_ID"), variable_name = "noise_condition")
levels(SAT_RP$noise_condition)[1] <- "high"
levels(SAT_RP$noise_condition)[2] <- "low"
SAT_RP[ , c(3)]<- as.factor(SAT_RP[ , c(3)])
SAT_RP$noise_condition  <- relevel(SAT_RP$noise_condition , "low")
names(SAT_RP)[names(SAT_RP) == 'value'] <- 'rel_performance'

#### compute descriptive statistics ####
descr_rel_performance_high <- describeBy(SAT_RP$rel_performance[SAT_RP$noise_condition == 'high'], SAT_RP$group[SAT_RP$noise_condition == 'high'])
descr_rel_performance_low <- describeBy(SAT_RP$rel_performance[SAT_RP$noise_condition == 'low'], SAT_RP$group[SAT_RP$noise_condition == 'low'])
descr_rel_performance_high <- ldply (descr_rel_performance_high, data.frame)
descr_rel_performance_low <-  ldply (descr_rel_performance_low, data.frame)
descr_rel_performance <- rbind(descr_rel_performance_high, descr_rel_performance_low)
descr_rel_performance[1,15] = "high"
descr_rel_performance[2,15] = "high"
descr_rel_performance[3,15] = "low"
descr_rel_performance[4,15] = "low"
names(descr_rel_performance)[names(descr_rel_performance) == 'V15'] <- 'noise_condition'
names(descr_rel_performance)[names(descr_rel_performance) == '.id'] <- 'group'
rm(descr_rel_performance_high,descr_rel_performance_low)

####  checking for assumptions ####
#### normality: Shapiro-Test ####
SAT_RP %>%
  group_by(noise_condition, group) %>%
  shapiro_test(rel_performance) 

#### homoscedasticity: Levene-Test ####
SAT_RP %>%
  group_by(group) %>%
  levene_test(rel_performance ~ noise_condition) 

#### 2-way mixed ANOVA (source: https://www.datanovia.com/en/lessons/mixed-anova-in-r/#two-way-mixed)####
res <- anova_test(
  data = SAT_RP, dv = rel_performance, wid = participant_ID,
  between = group, within = noise_condition, effect.size = "pes", type = 3, detailed = TRUE)
get_anova_table(res, correction = "GG")

#Analyze planning time (PT; time from stimulus onset until key press for 1st action)####
SAT_PT <- B3_SAT %>% select(group,participant_ID, mean_RT1_high_noise, mean_RT1_low_noise)

#reshape data, turtn noise condition into factor 
SAT_PT <-melt.data.frame(SAT_PT, id=c("participant_ID", "group"), variable_name = "noise_condition")
levels(SAT_PT$noise_condition)[1] <- "high"
levels(SAT_PT$noise_condition)[2] <- "low"
SAT_PT[ , c(3)]<- as.factor(SAT_PT[ , c(3)])
names(SAT_PT)[names(SAT_PT) == 'value'] <- 'planning_time'

#### compute descriptive statistics ####
descr_planning_time_high <- describeBy(SAT_PT$planning_time[SAT_PT$noise_condition == 'high'], SAT_PT$group[SAT_PT$noise_condition == 'high'])
descr_planning_time_low <- describeBy(SAT_PT$planning_time[SAT_PT$noise_condition == 'low'], SAT_PT$group[SAT_PT$noise_condition == 'low'])

descr_planning_time_high <- ldply (descr_planning_time_high, data.frame)
descr_planning_time_low <-  ldply (descr_planning_time_low, data.frame)
descr_planning_time <- rbind(descr_planning_time_high, descr_planning_time_low)
descr_planning_time[1,15] = "high"
descr_planning_time[2,15] = "high"
descr_planning_time[3,15] = "low"
descr_planning_time[4,15] = "low"
names(descr_planning_time)[names(descr_planning_time) == 'V15'] <- 'noise_condition'
names(descr_planning_time)[names(descr_planning_time) == '.id'] <- 'group'

#### normality: Shapiro-Test ####
SAT_PT %>%
  group_by(noise_condition, group) %>%
  shapiro_test(planning_time)

#### homoscedasticity: Levene-Test ####
SAT_PT %>%
  group_by(group) %>%
  levene_test(planning_time ~ noise_condition) 

#Planning time 2-way mixed ANOVA (source: https://www.datanovia.com/en/lessons/mixed-anova-in-r/#two-way-mixed)
res <- anova_test(
  data = SAT_PT, dv = planning_time, wid = participant_ID,
  between = group, within = noise_condition, effect.size = "pes", type = 3, detailed = TRUE)
get_anova_table(res, correction = "GG") 

#Analyze planning depth (PD, inferred measure based on discounted-low-probability pruning model) ####
#discounting + low-probability pruning analyses and group x condition comparison

# Planning depth and noise subset and data reshape for PD analyses 
SAT_PD <- subset(B3_SAT,select=c(group,participant_ID,balancing,disc_lowprob_PD_high_noise,disc_lowprob_PD_low_noise))

SAT_PD <-melt.data.frame(SAT_PD, id=c("group", "participant_ID", "balancing"), variable_name = "noise_condition")
levels(SAT_PD$noise_condition)[1] <- "high"
levels(SAT_PD$noise_condition)[2] <- "low"
SAT_PD[ , c(3)]<- as.factor(SAT_PD[ , c(3)])

names(SAT_PD)[names(SAT_PD) == 'value'] <- 'PD'

#### compute descriptive statistics #### 
descr_PD_disc_lowprob_high <- describeBy(SAT_PD$PD[SAT_PD$noise_condition == 'high'], SAT_PD$group[SAT_PD$noise_condition == 'high'])
descr_PD_disc_lowprob_low <- describeBy(SAT_PD$PD[SAT_PD$noise_condition == 'low'], SAT_PD$group[SAT_PD$noise_condition == 'low'])

descr_PD_disc_lowprob_high <- ldply (descr_PD_disc_lowprob_high, data.frame)
descr_PD_disc_lowprob_low <-  ldply (descr_PD_disc_lowprob_low, data.frame)
descr_PD_disc_lowprob <- rbind(descr_PD_disc_lowprob_high, descr_PD_disc_lowprob_low)
descr_PD_disc_lowprob[1,15] = "high"
descr_PD_disc_lowprob[2,15] = "high"
descr_PD_disc_lowprob[3,15] = "low"
descr_PD_disc_lowprob[4,15] = "low"
names(descr_PD_disc_lowprob)[names(descr_PD_disc_lowprob) == 'V15'] <- 'noise_condition'
names(descr_PD_disc_lowprob)[names(descr_PD_disc_lowprob) == '.id'] <- 'group'

rm(descr_PD_disc_lowprob_high,descr_PD_disc_lowprob_low)

#### normality: Shapiro-Test #####
SAT_PD %>%
  group_by(noise_condition, group) %>%
  shapiro_test(PD) 

#### homoscedasticity: Levene-Test ####
SAT_PD %>%
  group_by(group) %>%
  levene_test(PD ~ noise_condition) 


#### 2-way mixed ANOVA (source: https://www.datanovia.com/en/lessons/mixed-anova-in-r/#two-way-mixed)####
res <- anova_test(
  data = SAT_PD, dv = PD, wid = participant_ID,
  between = group, within = noise_condition, effect.size = "pes", type = 3, detailed = TRUE)
get_anova_table(res, correction = "GG") 

#End #######################################################################

