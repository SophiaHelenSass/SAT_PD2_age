################### Model comparison SAT PD 2 ####################################################
# by Sophia-Helen Sass

#clear workspace
rm(list = ls())

#load packages
library(ggpubr)
library(ggplot2)
library(data.table)
library(dplyr)
library(emmeans)
library(afex)
library(rstatix)
library(car)
library(ggplot2)
library(psych)
library(tidyverse)
library(ggpubr)
library(rstatix)
library(dplyr)
library(reshape)
library(plyr)

#### set working directory, load data from inference and format for analyses ####
setwd('your directory')

# full-breadth planning #
nll_ya_full_planning <- read.csv('Results_fullplanning/NLL_ya_group_fullplanning.csv')
nll_oa_full_planning <- read.csv('Results_fullplanning/NLL_oa_group_fullplanning.csv')
elbo_ya_full_planning <- read.csv('Results_fullplanning/ELBO_ya_group_fullplanning.csv')
elbo_oa_full_planning <- read.csv('Results_fullplanning/ELBO_oa_group_fullplanning.csv')

# discounted full-breadth planning #
nll_ya_disc_full_planning <- read.csv('Results_discount_hyperbolic_theta_alpha_kmax30/NLL_ya_group_discount_hyperbolic_theta_alpha_kmax30.csv')
nll_oa_disc_full_planning <- read.csv('Results_discount_hyperbolic_theta_alpha_kmax30/NLL_oa_group_discount_hyperbolic_theta_alpha_kmax30.csv')
elbo_ya_disc_full_planning <- read.csv('Results_discount_hyperbolic_theta_alpha_kmax30/ELBO_ya_group_discount_hyperbolic_theta_alpha_kmax30.csv')
elbo_oa_disc_full_planning <- read.csv('Results_discount_hyperbolic_theta_alpha_kmax30/ELBO_oa_group_discount_hyperbolic_theta_alpha_kmax30.csv')

# low-probability pruning #
nll_ya_lowprob_pruning <- read.csv('Results_lowprob_pruning/NLL_ya_group_lowprob_pruning.csv')
nll_oa_lowprob_pruning <- read.csv('Results_lowprob_pruning/NLL_oa_group_lowprob_pruning.csv')
elbo_ya_lowprob_pruning <- read.csv('Results_lowprob_pruning/ELBO_ya_group_lowprob_pruning.csv')
elbo_oa_lowprob_pruning <- read.csv('Results_lowprob_pruning/ELBO_oa_group_lowprob_pruning.csv')

# discounted low-probability pruning #
nll_ya_disc_lowprob_pruning <- read.csv('Results_lowprob_pruning_discount_hyperbolic_theta_kmax30/NLL_ya_group_lowprob_pruning_discount_hyperbolic_theta_kmax30.csv')
nll_oa_disc_lowprob_pruning <- read.csv('Results_lowprob_pruning_discount_hyperbolic_theta_kmax30/NLL_oa_group_lowprob_pruning_discount_hyperbolic_theta_kmax30.csv')
elbo_ya_disc_lowprob_pruning <- read.csv('Results_lowprob_pruning_discount_hyperbolic_theta_kmax30/ELBO_ya_group_lowprob_pruning_discount_hyperbolic_theta_kmax30.csv')
elbo_oa_disc_lowprob_pruning <- read.csv('Results_lowprob_pruning_discount_hyperbolic_theta_kmax30/ELBO_oa_group_lowprob_pruning_discount_hyperbolic_theta_kmax30.csv')


#name models and group group in a columnin NLL/BIC dataframe
nll_ya_full_planning$model <- NULL
nll_ya_full_planning$model <- "full_planning"
nll_ya_full_planning$group <- NULL
nll_ya_full_planning$group <- "young adults"
nll_oa_full_planning$model <- NULL
nll_oa_full_planning$model <- "full_planning"
nll_oa_full_planning$group <- NULL
nll_oa_full_planning$group <- "older adults"

nll_ya_disc_full_planning$model <- NULL
nll_ya_disc_full_planning$model <- "disc_full_planning"
nll_ya_disc_full_planning$group <- NULL
nll_ya_disc_full_planning$group <- "young adults"
nll_oa_disc_full_planning$model <- NULL
nll_oa_disc_full_planning$model <- "disc_full_planning"
nll_oa_disc_full_planning$group <- NULL
nll_oa_disc_full_planning$group <- "older adults"

nll_ya_lowprob_pruning$model <- NULL
nll_ya_lowprob_pruning$model <- "lowprob_pruning"
nll_ya_lowprob_pruning$group <- NULL
nll_ya_lowprob_pruning$group <- "young adults"
nll_oa_lowprob_pruning$model <- NULL
nll_oa_lowprob_pruning$model <- "lowprob_pruning"
nll_oa_lowprob_pruning$group <- NULL
nll_oa_lowprob_pruning$group <- "older adults"

nll_ya_disc_lowprob_pruning$model <- NULL
nll_ya_disc_lowprob_pruning$model <- "disc_lowprob_pruning"
nll_ya_disc_lowprob_pruning$group <- NULL
nll_ya_disc_lowprob_pruning$group <- "young adults"
nll_oa_disc_lowprob_pruning$model <- NULL
nll_oa_disc_lowprob_pruning$model <- "disc_lowprob_pruning"
nll_oa_disc_lowprob_pruning$group <- NULL
nll_oa_disc_lowprob_pruning$group <- "older adults"

# exclude participants with performance <650 fuel point in the SAT 
nll_full_planning <- rbind(nll_ya_full_planning, nll_oa_full_planning) 
nll_full_planning<-subset(nll_full_planning, ID != 1041& ID != 1103&ID != 1117&ID != 1461&ID != 1785& ID != 2101&ID != 2130&ID != 1119& ID != 1164&ID != 1524)
nll_lowprob_pruning <- rbind(nll_ya_lowprob_pruning, nll_oa_lowprob_pruning)
nll_lowprob_pruning<-subset(nll_lowprob_pruning, ID != 1041& ID != 1103&ID != 1117&ID != 1461&ID != 1785& ID != 2101&ID != 2130&ID != 1119& ID != 1164&ID != 1524)
nll_disc_lowprob_pruning <- rbind(nll_ya_disc_lowprob_pruning, nll_oa_disc_lowprob_pruning)
nll_disc_lowprob_pruning<-subset(nll_disc_lowprob_pruning, ID != 1041& ID != 1103&ID != 1117&ID != 1461&ID != 1785& ID != 2101&ID != 2130&ID != 1119& ID != 1164&ID != 1524)
nll_disc_full_planning <- rbind(nll_ya_disc_full_planning, nll_oa_disc_full_planning)
nll_disc_full_planning<-subset(nll_disc_full_planning, ID != 1041& ID != 1103&ID != 1117&ID != 1461&ID != 1785& ID != 2101&ID != 2130&ID != 1119& ID != 1164&ID != 1524)

#delete column that is unnecessary
nll_full_planning$subjIDs <- NULL
nll_disc_full_planning$subjIDs <- NULL
nll_lowprob_pruning$subjIDs <- NULL
nll_disc_lowprob_pruning$subjIDs <- NULL

#build a joint data frame for NLL/BIC for model comparison
# all models
nll_comp_allmodels_raw <- rbind(nll_full_planning,nll_disc_full_planning,nll_lowprob_pruning, nll_disc_lowprob_pruning)
nll_comp_allmodels_raw$model <- as.factor(nll_comp_allmodels_raw$model)

#define high and low noise conditions for BIC comparison
full_planning_hinoise <- subset(nll_full_planning,select=c( "BIC_hinoise_120_mean", "pseudo_Rsquare_1staction_hinoise_120_mean", "nll_1staction_hinoise_120_mean","model","group","ID"))
full_planning_hinoise$noise <- NULL
full_planning_hinoise$noise <- 'high'
full_planning_lonoise <- subset(nll_full_planning,select=c( "BIC_lonoise_120_mean", "pseudo_Rsquare_1staction_lonoise_120_mean","nll_1staction_lonoise_120_mean", "model","group", "ID"))
full_planning_lonoise$noise <- NULL
full_planning_lonoise$noise <- 'low'
setnames(full_planning_hinoise, old=c("BIC_hinoise_120_mean","pseudo_Rsquare_1staction_hinoise_120_mean","nll_1staction_hinoise_120_mean"), 
         new=c("BIC_noise_120_mean", "pseudo_Rsquare_1staction_noise_120_mean","nll_1staction_noise_120_mean"))
setnames(full_planning_lonoise, old=c("BIC_lonoise_120_mean","pseudo_Rsquare_1staction_lonoise_120_mean","nll_1staction_lonoise_120_mean"), 
         new=c("BIC_noise_120_mean", "pseudo_Rsquare_1staction_noise_120_mean","nll_1staction_noise_120_mean"))
full_planning_noise <- rbind(full_planning_hinoise, full_planning_lonoise)


disc_full_planning_hinoise <- subset(nll_disc_full_planning,select=c( "BIC_hinoise_120_mean", "pseudo_Rsquare_1staction_hinoise_120_mean", "nll_1staction_hinoise_120_mean","model","group","ID"))
disc_full_planning_hinoise$noise <- NULL
disc_full_planning_hinoise$noise <- 'high'
disc_full_planning_lonoise <- subset(nll_disc_full_planning,select=c( "BIC_lonoise_120_mean", "pseudo_Rsquare_1staction_lonoise_120_mean","nll_1staction_lonoise_120_mean", "model","group", "ID"))
disc_full_planning_lonoise$noise <- NULL
disc_full_planning_lonoise$noise <- 'low'
setnames(disc_full_planning_hinoise, old=c("BIC_hinoise_120_mean","pseudo_Rsquare_1staction_hinoise_120_mean","nll_1staction_hinoise_120_mean"), 
         new=c("BIC_noise_120_mean", "pseudo_Rsquare_1staction_noise_120_mean","nll_1staction_noise_120_mean"))
setnames(disc_full_planning_lonoise, old=c("BIC_lonoise_120_mean","pseudo_Rsquare_1staction_lonoise_120_mean","nll_1staction_lonoise_120_mean"),  
         new=c("BIC_noise_120_mean", "pseudo_Rsquare_1staction_noise_120_mean","nll_1staction_noise_120_mean"))
disc_full_planning_noise <- rbind(disc_full_planning_hinoise, disc_full_planning_lonoise)


lowprob_pruning_hinoise <- subset(nll_lowprob_pruning,select=c( "BIC_hinoise_120_mean", "pseudo_Rsquare_1staction_hinoise_120_mean", "nll_1staction_hinoise_120_mean","model","group","ID"))
lowprob_pruning_hinoise$noise <- NULL
lowprob_pruning_hinoise$noise <- 'high'
lowprob_pruning_lonoise <- subset(nll_lowprob_pruning,select=c( "BIC_lonoise_120_mean", "pseudo_Rsquare_1staction_lonoise_120_mean","nll_1staction_lonoise_120_mean", "model","group", "ID"))
lowprob_pruning_lonoise$noise <- NULL
lowprob_pruning_lonoise$noise <- 'low'
setnames(lowprob_pruning_hinoise, old=c("BIC_hinoise_120_mean","pseudo_Rsquare_1staction_hinoise_120_mean","nll_1staction_hinoise_120_mean"), 
         new=c("BIC_noise_120_mean", "pseudo_Rsquare_1staction_noise_120_mean","nll_1staction_noise_120_mean"))
setnames(lowprob_pruning_lonoise, old=c("BIC_lonoise_120_mean","pseudo_Rsquare_1staction_lonoise_120_mean","nll_1staction_lonoise_120_mean"),  
         new=c("BIC_noise_120_mean", "pseudo_Rsquare_1staction_noise_120_mean","nll_1staction_noise_120_mean"))
lowprob_pruning_noise <- rbind(lowprob_pruning_hinoise, lowprob_pruning_lonoise)


disc_lowprob_pruning_hinoise <- subset(nll_disc_lowprob_pruning,select=c( "BIC_hinoise_120_mean", "pseudo_Rsquare_1staction_hinoise_120_mean", "nll_1staction_hinoise_120_mean","model","group","ID"))
disc_lowprob_pruning_hinoise$noise <- NULL
disc_lowprob_pruning_hinoise$noise <- 'high'
disc_lowprob_pruning_lonoise <- subset(nll_disc_lowprob_pruning,select=c( "BIC_lonoise_120_mean", "pseudo_Rsquare_1staction_lonoise_120_mean","nll_1staction_lonoise_120_mean", "model","group", "ID"))
disc_lowprob_pruning_lonoise$noise <- NULL
disc_lowprob_pruning_lonoise$noise <- 'low'
setnames(disc_lowprob_pruning_hinoise, old=c("BIC_hinoise_120_mean","pseudo_Rsquare_1staction_hinoise_120_mean","nll_1staction_hinoise_120_mean"), 
         new=c("BIC_noise_120_mean", "pseudo_Rsquare_1staction_noise_120_mean","nll_1staction_noise_120_mean"))
setnames(disc_lowprob_pruning_lonoise, old=c("BIC_lonoise_120_mean","pseudo_Rsquare_1staction_lonoise_120_mean","nll_1staction_lonoise_120_mean"),  
         new=c("BIC_noise_120_mean", "pseudo_Rsquare_1staction_noise_120_mean","nll_1staction_noise_120_mean"))
disc_lowprob_pruning_noise <- rbind(disc_lowprob_pruning_hinoise, disc_lowprob_pruning_lonoise)

#create a joint data frame 
nll_comp_allmodels_noise <- rbind(full_planning_noise,disc_full_planning_noise,lowprob_pruning_noise, disc_lowprob_pruning_noise)
#set factors for analyses
nll_comp_allmodels_noise$model <- as.factor(nll_comp_allmodels_noise$model)
nll_comp_allmodels_noise$group <- as.factor(nll_comp_allmodels_noise$group)
nll_comp_allmodels_noise$group  <- relevel(nll_comp_allmodels_noise$group , "young adults")


############# BIC model comparison #################################################
##### descriptive statistics across groups and conditions #####
descr_BIC_full_planning <- describe(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$model == 'full_planning'])
descr_BIC_disc_full_planning <- describe(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$model == 'disc_full_planning'])
descr_BIC_lowprob_pruning <- describe(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$model == 'lowprob_pruning'])
descr_BIC_disc_lowprob_pruning <- describe(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$model == 'disc_lowprob_pruning'])
descr_BIC <- rbind(descr_BIC_full_planning, 
                   descr_BIC_disc_full_planning,
                   descr_BIC_lowprob_pruning,
                   descr_BIC_disc_lowprob_pruning)

descr_BIC[1,14] = "full-breadth planning"
descr_BIC[2,14] = "discounted full-breadth planning"
descr_BIC[3,14] = "low-probability pruning"
descr_BIC[4,14] = "discounted low-probability pruning"
names(descr_BIC)[names(descr_BIC) == 'V14'] <- 'model'

# set factors and order
descr_BIC$model <- as.factor(descr_BIC$model)
descr_BIC$model <- factor(descr_BIC$model, levels = c("full-breadth planning",
                                                      "discounted full-breadth planning", 
                                                      "low-probability pruning", 
                                                      "discounted low-probability pruning"))
##### plotting #####
# BIC bar plot with error bars 
BICplot <- ggplot(descr_BIC, aes(x=model, y=mean, group= model, fill=model)) + 
  geom_bar(stat="identity", color="black", width=0.7, alpha=.6, position=position_dodge(width=0.8)) + 
  scale_fill_manual(values=c("darkgrey", "lightgrey", "darkgreen", "lightgreen")) +
  theme_bw() + 
  scale_x_discrete(breaks=NULL) + 
  theme_light() + 
  theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank()) + 
  geom_errorbar(aes(ymin=mean-se, ymax=mean+se), width=0.2, size=0.9, position=position_dodge(width=0.8)) + 
  ylab(expression(paste("mean BIC"))) +  
  theme(
    plot.title=element_text(hjust=0.5, size=12),
    axis.text.y=element_text(face="bold", size=12),
    title=element_text(face="bold", size=16),
    axis.title.x=element_blank() 
  ) + 
  scale_y_continuous(limits=c(0, 120)) + 
  coord_cartesian(ylim=c(60, 80))

BICplot

#### compute delta BIC #### 
# Create a function to compute the difference and evaluate the size
compute_difference <- function(model1, model2, bic1, bic2) {
  delta_bic <- bic2 - bic1
  abs_delta_bic <- abs(delta_bic)
  breaks <- c(-Inf, 0, 2, 6, 10, Inf)
  labels <- c("anecdotal", "positive", "strong", "very strong")
  evaluation <- labels[findInterval(abs_delta_bic, breaks, rightmost.closed = TRUE)]
  
  return(data.frame(
    "compared_models" = paste(model1, "vs", model2),
    "BIC_value_model_1" = round(bic1, 2),
    "BIC_value_model_2" = round(bic2, 2),
    "Delta_BIC" = round(delta_bic, 2),
    "Abs_Delta_BIC" = round(abs_delta_bic, 2),
    "Evaluation" = as.character(evaluation)
  ))
}

# Create all possible pairs of models
model_pairs <- combn(levels(descr_BIC$model), 2, simplify = TRUE)

# Apply the function to compute differences and evaluations
result_table <- t(apply(model_pairs, 2, function(pair) {
  model1 <- pair[1]
  model2 <- pair[2]
  bic1 <- subset(descr_BIC, model == model1)$mean
  bic2 <- subset(descr_BIC, model == model2)$mean
  compute_difference(model1, model2, bic1, bic2)
}))

# Convert result_table to a data frame
result_table <- as.data.frame(result_table)

# Print the rounded result_table
print(result_table)

# Apply the function to compute differences and evaluations
result_table <- t(apply(model_pairs, 2, function(pair) {
  model1 <- pair[1]
  model2 <- pair[2]
  bic1 <- subset(descr_BIC, model == model1)$mean
  bic2 <- subset(descr_BIC, model == model2)$mean
  compute_difference(model1, model2, bic1, bic2)
}))

# Convert result_table to a data frame
result_table_small <- as.data.frame(result_table)
result_table <- rbind(result_table_small[[1]][[1]],
                      result_table_small[[2]][[1]],
                      result_table_small[[3]][[1]],
                      result_table_small[[4]][[1]],
                      result_table_small[[5]][[1]],
                      result_table_small[[6]][[1]])

# plot delta BIC 
delta_BIC_plot <- ggplot(result_table, aes(x = compared_models, y = Delta_BIC)) +
  geom_bar(stat = "identity", color = "black", fill = "grey",alpha = 0.7) +
    theme_minimal() +
  theme(
    axis.text.x = element_text(size = 12),  
    axis.text.y = element_text(size = 12),  
    axis.title.x = element_text(face = "bold", size = 15),
    axis.title.y = element_text(face = "bold", size = 15),
    title = element_text(face = "bold", size = 16),
    plot.title = element_text(hjust = 0.5),
    panel.grid.major.y = element_blank(),  
    panel.grid.minor.y = element_blank()   
  ) +
  labs(y = expression(Delta * "BIC"), x = "compared models", title = expression("Comparison of model evidence based on " * Delta * " BIC")) +
  geom_hline(yintercept = 0, color = "black") +   
  coord_flip()  

delta_BIC_plot


############# Rho� model comparison #################################################
#### descriptives across condition and age group ####
descr_rho2_full_planning <- describe(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$model == 'full_planning'])
descr_rho2_disc_alpha <- describe(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$model == 'disc_full_planning'])
descr_rho2_lowprob_pruning <- describe(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$model == 'lowprob_pruning'])
descr_rho2_disc_lowprob_pruning <- describe(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$model == 'disc_lowprob_pruning'])

descr_rho2 <- rbind(descr_rho2_full_planning, 
                   descr_rho2_disc_alpha,
                   descr_rho2_lowprob_pruning,
                   descr_rho2_disc_lowprob_pruning)

descr_rho2[1,14] = "full-breadth planning"
descr_rho2[2,14] = "discounted full-breadth planning"
descr_rho2[3,14] = "low-probability pruning"
descr_rho2[4,14] = "discounted low-probability pruning"

names(descr_rho2)[names(descr_rho2) == 'V14'] <- 'model'
descr_rho2$model <- as.factor(descr_rho2$model)
descr_rho2$model <- factor(descr_rho2$model, levels = c("full-breadth planning",
                                                        "discounted full-breadth planning", 
                                                        "low-probability pruning", 
                                                        "discounted low-probability pruning"))

#### plotting ####
# plot bar plot with errorbars 
rho2plot <- ggplot(descr_rho2, aes(x=model, y=mean, group= model, fill=model)) + 
  geom_bar(stat="identity", color="black", width=0.7, alpha=.6, position=position_dodge(width=0.8)) + 
  scale_fill_manual(values=c("darkgrey", "lightgrey", "darkgreen", "lightgreen")) +
  theme_bw() + 
  scale_x_discrete(breaks=NULL) + 
  theme_light() + 
  theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank()) + 
  geom_errorbar(aes(ymin=mean-se, ymax=mean+se), width=0.2, size=0.9, position=position_dodge(width=0.8)) + 
  ylab(expression(paste("mean ", rho^2))) +  # Using expression to include Greek letter rho (??)
  theme(
    plot.title=element_text(hjust=0.5, size=12),
    axis.text.y=element_text(face="bold", size=12),
    title=element_text(face="bold", size=16),
    axis.title.x=element_blank()  # Remove x-axis title
  ) + 
  scale_y_continuous(limits=c(0, 120)) + 
  coord_cartesian(ylim=c(0.25, 0.4))

rho2plot

############# Noise condition split: BIC model comparison #################################################
#same procedure for mean across age groups separated for noise conditions
#### descriptives split by noise condition ####
descr_BIC_high_full_planning <- ldply (describeBy(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$noise == 'high' & nll_comp_allmodels_noise$model == 'full_planning'],
                                                   nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'high'& nll_comp_allmodels_noise$model == 'full_planning']))

descr_BIC_low_full_planning <- ldply (describeBy(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$noise == 'low' & nll_comp_allmodels_noise$model == 'full_planning'], 
                                                  nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'low'& nll_comp_allmodels_noise$model == 'full_planning']))

descr_BIC_high_disc_full_planning <- ldply (describeBy(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$noise == 'high' & nll_comp_allmodels_noise$model == 'disc_full_planning'], 
                                                        nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'high'& nll_comp_allmodels_noise$model == 'disc_full_planning']))
descr_BIC_low_disc_full_planning <- ldply (describeBy(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$noise == 'low' & nll_comp_allmodels_noise$model == 'disc_full_planning'], 
                                                       nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'low'& nll_comp_allmodels_noise$model == 'disc_full_planning']))

descr_BIC_high_lowprob_pruning <- ldply (describeBy(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$noise == 'high' & nll_comp_allmodels_noise$model == 'lowprob_pruning'], 
                                                     nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'high'& nll_comp_allmodels_noise$model == 'lowprob_pruning']))
descr_BIC_low_lowprob_pruning <- ldply (describeBy(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$noise == 'low' & nll_comp_allmodels_noise$model == 'lowprob_pruning'], 
                                                    nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'low'& nll_comp_allmodels_noise$model == 'lowprob_pruning']))

descr_BIC_high_disc_lowprob_pruning <- ldply (describeBy(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$noise == 'high' & nll_comp_allmodels_noise$model == 'disc_lowprob_pruning'], 
                                                          nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'high'& nll_comp_allmodels_noise$model == 'disc_lowprob_pruning']))
descr_BIC_low_disc_lowprob_pruning <- ldply (describeBy(nll_comp_allmodels_noise$BIC_noise_120_mean[nll_comp_allmodels_noise$noise == 'low' & nll_comp_allmodels_noise$model == 'disc_lowprob_pruning'], 
                                                         nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'low'& nll_comp_allmodels_noise$model == 'disc_lowprob_pruning']))


descr_BIC <- rbind(descr_BIC_low_full_planning, descr_BIC_high_full_planning,
                    descr_BIC_low_disc_full_planning, descr_BIC_high_disc_full_planning, 
                    descr_BIC_low_lowprob_pruning,descr_BIC_high_lowprob_pruning,
                    descr_BIC_low_disc_lowprob_pruning,descr_BIC_high_disc_lowprob_pruning)


descr_BIC[1,15] = "low"
descr_BIC[2,15] = "low"
descr_BIC[3,15] = "high"
descr_BIC[4,15] = "high"
descr_BIC[5,15] = "low"
descr_BIC[6,15] = "low"
descr_BIC[7,15] = "high"
descr_BIC[8,15] = "high"
descr_BIC[9,15] = "low"
descr_BIC[10,15] = "low"
descr_BIC[11,15] = "high"
descr_BIC[12,15] = "high"
descr_BIC[13,15] = "low"
descr_BIC[14,15] = "low"
descr_BIC[15,15] = "high"
descr_BIC[16,15] = "high"

descr_BIC[1,16] = "full-breadth planning"
descr_BIC[2,16] = "full-breadth planning"
descr_BIC[3,16] = "full-breadth planning"
descr_BIC[4,16] = "full-breadth planning"
descr_BIC[5,16] = "discounted full-breadth planning"
descr_BIC[6,16] = "discounted full-breadth planning"
descr_BIC[7,16] = "discounted full-breadth planning"
descr_BIC[8,16] = "discounted full-breadth planning"
descr_BIC[9,16] = "low-probability pruning"
descr_BIC[10,16] = "low-probability pruning"
descr_BIC[11,16] = "low-probability pruning"
descr_BIC[12,16] = "low-probability pruning"
descr_BIC[13,16] = "discounted low-probability pruning"
descr_BIC[14,16] = "discounted low-probability pruning"
descr_BIC[15,16] = "discounted low-probability pruning"
descr_BIC[16,16] = "discounted low-probability pruning"

names(descr_BIC)[names(descr_BIC) == 'V15'] <- 'noise'
names(descr_BIC)[names(descr_BIC) == 'V16'] <- 'model'
names(descr_BIC)[names(descr_BIC) == '.id'] <- 'group'
descr_BIC$noise <- as.factor(descr_BIC$noise)
descr_BIC$group <- as.factor(descr_BIC$group)
descr_BIC$model <- as.factor(descr_BIC$model)
descr_BIC$noise <- relevel(descr_BIC$noise , "low")
descr_BIC$group <- relevel(descr_BIC$group , "young adults")
descr_BIC$model <- relevel(descr_BIC$model , "full-breadth planning",
                            "discounted full-breadth planning",
                            "low-probability pruning",
                            "discounted low-probability pruning")

descr_BIC$model <- factor(descr_BIC$model, levels = c("full-breadth planning", 
                                                        "discounted full-breadth planning",
                                                        "low-probability pruning",
                                                        "discounted low-probability pruning"))

#### plotting ####
# plot bar plot with errorbars 
# Define colors for each model
model_colors <- c("darkgrey", "lightgrey", "darkgreen", "lightgreen")

BICplot <- ggplot(descr_BIC, aes(x=noise, y=mean, group= model, fill=model)) + 
  geom_bar(stat="identity", color="black", width=0.7, alpha = .6,
           position=position_dodge(width=0.8)) + 
  facet_grid(. ~ group) + 
  theme_bw() + 
  theme(axis.text.x = element_text(angle = 90)) +
  theme_light() +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank()) +
  geom_errorbar(aes(ymin=mean-se, ymax=mean+se), width=.2,  size = 0.9, 
                position=position_dodge(width=0.8)) +
  xlab("noise") +
  ylab(expression(paste("mean ", rho^2))) +
  theme(plot.title=element_text(hjust=0.5, size=12),
        axis.text.y = element_text(face = "bold", size=12),
        title=element_text(face = "bold", size = 16)) +
  scale_y_continuous(limits = c(0, 120)) +
  coord_cartesian(ylim=c(50,80 )) +
  scale_fill_manual(values = model_colors)  # Set the colors for each model

BICplot


#### compute delta BIC ####
descr_BIC_high <- subset(descr_BIC, noise == "high")
model_pairs_high <- combn(levels(descr_BIC_high$model), 2, simplify = TRUE)

# Apply the function to compute differences and evaluations
result_table_high <- t(apply(model_pairs_high, 2, function(pair) {
  model1 <- pair[1]
  model2 <- pair[2]
  bic1 <- subset(descr_BIC_high, model == model1)$mean
  bic2 <- subset(descr_BIC_high, model == model2)$mean
  compute_difference(model1, model2, bic1, bic2)
}))

# Convert result_table to a data frame
result_table_small_high<- as.data.frame(result_table_high)
result_table_high <- rbind(result_table_small_high[[1]][[1]],
                      result_table_small_high[[2]][[1]],
                      result_table_small_high[[3]][[1]],
                      result_table_small_high[[4]][[1]],
                      result_table_small_high[[5]][[1]],
                      result_table_small_high[[6]][[1]])

descr_BIC_low <- subset(descr_BIC, noise == "low")
model_pairs_low <- combn(levels(descr_BIC_low$model), 2, simplify = TRUE)

# Apply the function to compute differences and evaluations
result_table_low <- t(apply(model_pairs_low, 2, function(pair) {
  model1 <- pair[1]
  model2 <- pair[2]
  bic1 <- subset(descr_BIC_low, model == model1)$mean
  bic2 <- subset(descr_BIC_low, model == model2)$mean
  compute_difference(model1, model2, bic1, bic2)
}))

# Convert result_table to a data frame
result_table_small_low<- as.data.frame(result_table_low)
result_table_low <- rbind(result_table_small_low[[1]][[1]],
                           result_table_small_low[[2]][[1]],
                           result_table_small_low[[3]][[1]],
                           result_table_small_low[[4]][[1]],
                           result_table_small_low[[5]][[1]],
                           result_table_small_low[[6]][[1]])



############# Noise condition split: Rho� model comparison #################################################
#same procedure for mean across age groups separated for noise conditions
#### descriptives split by nosie condition ####
descr_rho2_high_full_planning <- ldply (describeBy(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$noise == 'high' & nll_comp_allmodels_noise$model == 'full_planning'],
                                                   nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'high'& nll_comp_allmodels_noise$model == 'full_planning']))

descr_rho2_low_full_planning <- ldply (describeBy(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$noise == 'low' & nll_comp_allmodels_noise$model == 'full_planning'], 
                                                 nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'low'& nll_comp_allmodels_noise$model == 'full_planning']))

descr_rho2_high_disc_full_planning <- ldply (describeBy(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$noise == 'high' & nll_comp_allmodels_noise$model == 'disc_full_planning'], 
                                                             nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'high'& nll_comp_allmodels_noise$model == 'disc_full_planning']))
descr_rho2_low_disc_full_planning <- ldply (describeBy(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$noise == 'low' & nll_comp_allmodels_noise$model == 'disc_full_planning'], 
                                                            nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'low'& nll_comp_allmodels_noise$model == 'disc_full_planning']))

descr_rho2_high_lowprob_pruning <- ldply (describeBy(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$noise == 'high' & nll_comp_allmodels_noise$model == 'lowprob_pruning'], 
                                                   nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'high'& nll_comp_allmodels_noise$model == 'lowprob_pruning']))
descr_rho2_low_lowprob_pruning <- ldply (describeBy(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$noise == 'low' & nll_comp_allmodels_noise$model == 'lowprob_pruning'], 
                                                  nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'low'& nll_comp_allmodels_noise$model == 'lowprob_pruning']))

descr_rho2_high_disc_lowprob_pruning <- ldply (describeBy(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$noise == 'high' & nll_comp_allmodels_noise$model == 'disc_lowprob_pruning'], 
                                                            nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'high'& nll_comp_allmodels_noise$model == 'disc_lowprob_pruning']))
descr_rho2_low_disc_lowprob_pruning <- ldply (describeBy(nll_comp_allmodels_noise$pseudo_Rsquare_1staction_noise_120_mean[nll_comp_allmodels_noise$noise == 'low' & nll_comp_allmodels_noise$model == 'disc_lowprob_pruning'], 
                                                           nll_comp_allmodels_noise$group[nll_comp_allmodels_noise$noise == 'low'& nll_comp_allmodels_noise$model == 'disc_lowprob_pruning']))


descr_rho2 <- rbind(descr_rho2_low_full_planning, descr_rho2_high_full_planning,
                   descr_rho2_low_disc_full_planning, descr_rho2_high_disc_full_planning, 
                   descr_rho2_low_lowprob_pruning,descr_rho2_high_lowprob_pruning,
                   descr_rho2_low_disc_lowprob_pruning,descr_rho2_high_disc_lowprob_pruning)


descr_rho2[1,15] = "low"
descr_rho2[2,15] = "low"
descr_rho2[3,15] = "high"
descr_rho2[4,15] = "high"
descr_rho2[5,15] = "low"
descr_rho2[6,15] = "low"
descr_rho2[7,15] = "high"
descr_rho2[8,15] = "high"
descr_rho2[9,15] = "low"
descr_rho2[10,15] = "low"
descr_rho2[11,15] = "high"
descr_rho2[12,15] = "high"
descr_rho2[13,15] = "low"
descr_rho2[14,15] = "low"
descr_rho2[15,15] = "high"
descr_rho2[16,15] = "high"

descr_rho2[1,16] = "full-breadth planning"
descr_rho2[2,16] = "full-breadth planning"
descr_rho2[3,16] = "full-breadth planning"
descr_rho2[4,16] = "full-breadth planning"
descr_rho2[5,16] = "discounted full-breadth planning"
descr_rho2[6,16] = "discounted full-breadth planning"
descr_rho2[7,16] = "discounted full-breadth planning"
descr_rho2[8,16] = "discounted full-breadth planning"
descr_rho2[9,16] = "low-probability pruning"
descr_rho2[10,16] = "low-probability pruning"
descr_rho2[11,16] = "low-probability pruning"
descr_rho2[12,16] = "low-probability pruning"
descr_rho2[13,16] = "discounted low-probability pruning"
descr_rho2[14,16] = "discounted low-probability pruning"
descr_rho2[15,16] = "discounted low-probability pruning"
descr_rho2[16,16] = "discounted low-probability pruning"

names(descr_rho2)[names(descr_rho2) == 'V15'] <- 'noise'
names(descr_rho2)[names(descr_rho2) == 'V16'] <- 'model'
names(descr_rho2)[names(descr_rho2) == '.id'] <- 'group'
descr_rho2$noise <- as.factor(descr_rho2$noise)
descr_rho2$group <- as.factor(descr_rho2$group)
descr_rho2$model <- as.factor(descr_rho2$model)
descr_rho2$noise <- relevel(descr_rho2$noise , "low")
descr_rho2$group <- relevel(descr_rho2$group , "young adults")
descr_rho2$model <- relevel(descr_rho2$model , "full-breadth planning",
                            "discounted full-breadth planning",
                            "low-probability pruning",
                            "discounted low-probability pruning")

descr_rho2$model <- factor(descr_rho2$model, levels = c("full-breadth planning", 
                                                        "discounted full-breadth planning",
                                                        "low-probability pruning",
                                                        "discounted low-probability pruning"))

#### plotting ####
# plot bar plot with errorbars 
# Define colors for each model
model_colors <- c("darkgrey", "lightgrey", "darkgreen", "lightgreen")

rho2plot <- ggplot(descr_rho2, aes(x=noise, y=mean, group= model, fill=model)) + 
  geom_bar(stat="identity", color="black", width=0.7, alpha = .6,
           position=position_dodge(width=0.8)) + 
  facet_grid(. ~ group) + 
  theme_bw() + 
  theme(axis.text.x = element_text(angle = 90)) +
  theme_light() +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank()) +
  geom_errorbar(aes(ymin=mean-se, ymax=mean+se), width=.2,  size = 0.9, 
                position=position_dodge(width=0.8)) +
  xlab("noise") +
  ylab(expression(paste("mean ", rho^2))) +
  theme(plot.title=element_text(hjust=0.5, size=12),
        axis.text.y = element_text(face = "bold", size=12),
        title=element_text(face = "bold", size = 16)) +
  scale_y_continuous(limits = c(0, 120)) +
  coord_cartesian(ylim=c(0.2,0.6 )) +
  scale_fill_manual(values = model_colors)  # Set the colors for each model

rho2plot


# End ####



