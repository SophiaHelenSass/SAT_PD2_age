#by Sophia-Helen Sass
#linear regression analyses####

####preparation####
#clear workspace
rm(list = ls())

# install.packages("car");
# install.packages("ggplot2")
# install.packages("psych")
# install.packages("rstatix")
# install.packages("tidyverse")
# install.packages("ggpubr")
# install.packages("reshape")
# install.packages("dplyr")
# install.packages("plyr")
# install.packages ("mctest")

library(mctest)
library(car)
library(ggplot2)
library(psych)
library(tidyverse)
library(ggpubr)
library(rstatix)
library(dplyr)
library(reshape)
library(plyr)
library(QuantPsyc)


#load data
setwd("you directory")
B3_SAT<- read.csv("SAT_neuro_quest_all_data.csv", header = TRUE)
B3_SAT$group <- as.factor(B3_SAT$group)
B3_SAT$group  <- relevel(B3_SAT$group , "young adults")

####lm performance and cognitive co-variates####
lm_performance_cogcov= lm(rel_gain_overall~group + IDP_ACC_rel + SWM_acc_all + nfc_total + mean_RT1_overall, data = B3_SAT) #Create a linear regression with two variables
summary(lm_performance_cogcov) 

lm_performance_cogcov[["model"]][["group"]]<- as.double(lm_performance_cogcov[["model"]][["group"]])
lm.beta(lm_performance_cogcov)

confint(lm_performance_cogcov, '(Intercept)', level=0.95)
confint(lm_performance_cogcov, 'groupolder adults', level=0.95)
confint(lm_performance_cogcov, 'IDP_ACC_rel', level=0.95)
confint(lm_performance_cogcov, 'SWM_acc_all', level=0.95)
confint(lm_performance_cogcov, 'nfc_total', level=0.95)
confint(lm_performance_cogcov, 'mean_RT1_overall', level=0.95)



####lm performance and model parameters####
lm_performans_param= lm(rel_gain_overall~group + disc_lowprob_prun_beta + disc_lowprob_prun_theta + disc_lowprob_prun_kappa + 
                  disc_lowprob_PD_overall, data = B3_SAT) 
summary(lm_performans_param) 

lm_performans_param[["model"]][["group"]]<- as.double(lm_performans_param[["model"]][["group"]])
lm.beta(lm_performans_param)

confint(lm_performans_param, '(Intercept)', level=0.95)
confint(lm_performans_param, 'groupolder adults', level=0.95)
confint(lm_performans_param, 'disc_lowprob_prun_beta', level=0.95)
confint(lm_performans_param, 'disc_lowprob_prun_theta', level=0.95)
confint(lm_performans_param, 'disc_lowprob_prun_kappa', level=0.95)
confint(lm_performans_param, 'disc_lowprob_PD_overall', level=0.95)

#End####
