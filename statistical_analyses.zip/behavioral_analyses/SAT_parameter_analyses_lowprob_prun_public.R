#by Sophia-Helen Sass                                                         ############################
################### statistical analysis of Planning Depth in the SAT PD 2.0 ############################
#clear workspace
rm(list = ls())

# install.packages("car");
# install.packages("ggplot2")
# install.packages("psych")
# install.packages("rstatix")
# install.packages("tidyverse")
# install.packages("ggpubr")
# install.packages("reshape")
# install.packages("dplyr")
# install.packages("plyr")

library(car)
library(ggplot2)
library(psych)
library(tidyverse)
library(ggpubr)
library(rstatix)
library(dplyr)
library(reshape)
library(plyr)

#set working and data directory
setwd("your directory")
B3_SAT<- read.csv("SAT_neuro_quest_all_data.csv", header = TRUE)
B3_SAT$group <- as.factor(B3_SAT$group)
B3_SAT$group  <- relevel(B3_SAT$group , "young adults")
subOA <- subset(B3_SAT, group == "older adults")
subYA<- subset(B3_SAT, group == "young adults")

#all analyses refer to the parameters inferred from the discounted low-probability pruning model, 
#which was the winning model in the model comparison

#BETA#####################################################
####  checking for assumptions ####
SAT_disc_lowprob_prun <- subset(B3_SAT, select=c(group,participant_ID,balancing,disc_lowprob_prun_beta))

##### normality: Shapiro-Test #####
SAT_disc_lowprob_prun %>%
  group_by(group) %>%
  shapiro_test(disc_lowprob_prun_beta) 

#young adults
hist(subYA$disc_lowprob_prun_beta,probability=T, main="Histogram of beta in young adults",xlab="beta in SAT (discounting + lowprob pruning)")

#older adults
hist(subOA$disc_lowprob_prun_beta,probability=T, main="Histogram of beta in older adults",xlab="beta in SAT (discounting + lowprob pruning)")

##### homoscedasticity: Levene-Test #####
SAT_disc_lowprob_prun %>%
  levene_test(disc_lowprob_prun_beta~group) 


#### group x condition comparison ####
##### descriptives #####
descr_beta_disc_lowprob_prun<- describeBy(SAT_disc_lowprob_prun$disc_lowprob_prun_beta, SAT_disc_lowprob_prun$group)
descr_beta_disc_lowprob_prun <- ldply (descr_beta_disc_lowprob_prun, data.frame)
names(descr_beta_disc_lowprob_prun)[names(descr_beta_disc_lowprob_prun) == '.id'] <- 'group'

##### plotting #####
betaplot_disc_lowprob_prun <- ggplot(descr_beta_disc_lowprob_prun, aes(x=group, y=mean)) + 
  geom_point(data = SAT_disc_lowprob_prun, size = 1.5, aes(y = disc_lowprob_prun_beta, x = group),
             position = position_jitter(width = 0.03)) +
  geom_bar(stat="identity", color="black", width=0.7, alpha = 0.3) +
  geom_errorbar(aes(ymin=mean-se, ymax=mean+se), width=.2,  size = 1.2) +  
  xlab("age group") +
  ylab("beta") +
  theme(
    axis.title.y = element_text(hjust=0.5, size = 15),
    axis.text.y = element_text(face = "bold", size = 15),  
    axis.line = element_line(),
    axis.ticks.x = element_blank(),
    title = element_text(face = "bold", size = 10),
    axis.title.x = element_blank(),  
    axis.text.x = element_blank(),   
    panel.background = element_rect(fill = "white"),
    panel.border = element_rect(color = "black", fill = NA, size = 1)) +
  theme(legend.text = element_text(size = 10)) +
  scale_y_continuous(limits = c(0, 4)) +
  coord_cartesian(ylim=c(0.5,4))

betaplot_disc_lowprob_prun

##### statistical test #####
#wilcox-test
disc_lowprob_prun_beta_test <- wilcox.test(B3_SAT$disc_lowprob_prun_beta~B3_SAT$group, var.equal = FALSE)
disc_lowprob_prun_beta_test

#THETA##############################
SAT_disc_lowprob_prun <- subset(B3_SAT, select=c(group,participant_ID,balancing,disc_lowprob_prun_theta))
#### checking for assumptions ####
##### normality: Shapiro-Test #####
SAT_disc_lowprob_prun %>%
  group_by(group) %>%
  shapiro_test(disc_lowprob_prun_theta) 

#young adults
hist(subYA$disc_lowprob_prun_theta,probability=T, main="Histogram of theta in young adults",xlab="theta in SAT (discounting + lowprob pruning)")

#older adultsx
hist(subOA$disc_lowprob_prun_theta,probability=T, main="Histogram of theta in older adults",xlab="theta in SAT (discounting + lowprob pruning)")

##### homoscedasticity: Levene-Test #####
SAT_disc_lowprob_prun %>%
  levene_test(disc_lowprob_prun_theta~group) 

#### group x condition comparison ####
##### descriptives #####
descr_theta_disc_lowprob_prun<- describeBy(SAT_disc_lowprob_prun$disc_lowprob_prun_theta, SAT_disc_lowprob_prun$group)
descr_theta_disc_lowprob_prun <- ldply (descr_theta_disc_lowprob_prun, data.frame)
names(descr_theta_disc_lowprob_prun)[names(descr_theta_disc_lowprob_prun) == '.id'] <- 'group'

##### plotting #####
thetaplot_disc_lowprob_prun <- ggplot(descr_theta_disc_lowprob_prun, aes(x=group, y=mean)) + 
  geom_point(data = SAT_disc_lowprob_prun, size = 0.9, aes(y = disc_lowprob_prun_theta, x = group))+
  geom_bar(stat="identity", color="black", width=0.7, alpha = 0.3) +
  geom_errorbar(aes(ymin=mean-se, ymax=mean+se), width=.2,  size = 0.1)+
  xlab("age group") +
  ylab("mean theta") +
  theme(plot.title=element_text(hjust=0.5) ,
        axis.text.x = element_text( size=9),
        axis.text.y = element_text( face = "bold",size=7),
        title=element_text(face = "bold", size = 10)) +
  theme(legend.text = element_text(size = 10)) +
  scale_y_continuous(limits = c(-2, 2))+
  coord_cartesian(ylim=c(-2,2))

thetaplot_disc_lowprob_prun

##### statistical test #####
#wilcox-test
mean_theta_1testYA <- wilcox.test(B3_SAT$disc_lowprob_prun_theta[B3_SAT$group == "young adults"], var.equal = FALSE)
mean_theta_1testYA
mean_theta_1testOA <- wilcox.test(B3_SAT$disc_lowprob_prun_theta[B3_SAT$group == "older adults"], var.equal = FALSE)
mean_theta_1testOA
mean_theta_grouptest <- wilcox.test(B3_SAT$disc_lowprob_prun_theta~B3_SAT$group, var.equal = FALSE)
mean_theta_grouptest


#KAPPA##############################
SAT_disc_lowprob_prun <- subset(B3_SAT, select= c(group,participant_ID,balancing,disc_lowprob_prun_kappa))
#### checking for assumptions ####
##### normality: Shapiro-Test #####
SAT_disc_lowprob_prun %>%
  group_by(group) %>%
  shapiro_test(disc_lowprob_prun_kappa) 

##### homoscedasticity: Levene-Test #####
SAT_disc_lowprob_prun %>%
  levene_test(disc_lowprob_prun_kappa~group) 

#young adults
hist(subYA$disc_lowprob_prun_kappa,probability=T, main="Histogram of kappa in young adults",xlab="kappa in SAT (discounting + lowprob pruning)")

#older adults
hist(subOA$disc_lowprob_prun_kappa,probability=T, main="Histogram of kappa in older adults",xlab="kappa in SAT (discounting + lowprob pruning)")

#### group x condition comparison ####
##### descriptives #####
descr_kappa_disc_lowprob_prun<- describeBy(SAT_disc_lowprob_prun$disc_lowprob_prun_kappa, SAT_disc_lowprob_prun$group)
descr_kappa_disc_lowprob_prun <- ldply (descr_kappa_disc_lowprob_prun, data.frame)
names(descr_kappa_disc_lowprob_prun)[names(descr_kappa_disc_lowprob_prun) == '.id'] <- 'group'

##### plotting #####
kappaplot_disc_lowprob_prun <- ggplot(descr_kappa_disc_lowprob_prun, aes(x=group, y=mean)) + 
    geom_point(data = SAT_disc_lowprob_prun, size = 1.5, aes(y = disc_lowprob_prun_kappa, x = group,color="darkgrey", alpha=0.9),
             position = position_jitter(width = 0.03)) +
  geom_bar(stat="identity", color="black", width=0.7, alpha = 0.3) +
  geom_errorbar(aes(ymin=mean-se, ymax=mean+se), width=.2,  size = 1) +  
  xlab("age group") +
  ylab("kappa") +
  theme(
    axis.title.y = element_text(hjust=0.5, size = 15),
    axis.text.y = element_text(face = "bold", size = 15),  # Increase text size here
    axis.line = element_line(),
    axis.ticks.x = element_blank(),
    title = element_text(face = "bold", size = 10),
    axis.title.x = element_blank(),  
    axis.text.x = element_blank(),   
    panel.background = element_rect(fill = "white"),
    panel.border = element_rect(color = "black", fill = NA, size = 1)  # Add a black frame around the plot
  ) +
  theme(legend.text = element_text(size = 10)) +
  scale_y_continuous(limits = c(0, 30)) +
  coord_cartesian(ylim=c(0,30))

kappaplot_disc_lowprob_prun

##### statistical test #####
#wilcox-test
disc_lowprob_prun_kappa_test <- wilcox.test(B3_SAT$disc_lowprob_prun_kappa~B3_SAT$group, var.equal = FALSE)
disc_lowprob_prun_kappa_test

# END ################
