### Post-hoc: Mixed analysis of variance to compare planning times for deterministic and probabilistic first actions ####
#clear workspace
rm(list = ls())

# install.packages("car");
# install.packages("ggplot2")
# install.packages("psych")
# install.packages("rstatix")
# install.packages("tidyverse")
# install.packages("ggpubr")
# install.packages("reshape")
# install.packages("dplyr")
# install.packages("plyr")
# install.packages("afex")

library(car)
library(ggplot2)
library(psych)
library(tidyverse)
library(ggpubr)
library(rstatix)
library(dplyr)
library(reshape)
library(plyr)
library(afex)

#preparation####
#set working and data directory
setwd("your directory")

B3_SAT<- read.csv("SAT_neuro_quest_all_data.csv", header = TRUE)
B3_SAT$group <- as.factor(B3_SAT$group)
B3_SAT$group  <- relevel(B3_SAT$group , "young adults")


####### RT1 and noise subset and data reshape for RT1 analyses #####
SAT <- subset(B3_SAT,select=c("group","participant_ID","balancing","mean_RT1_low_noise_jump","mean_RT1_low_noise_move","mean_RT1_high_noise_jump","mean_RT1_high_noise_move"))
SAT <-melt.data.frame(SAT, id=c("group", "participant_ID","balancing"), variable_name = "noise_action")
levels(SAT$noise_action)[1] <- "lowjump"
levels(SAT$noise_action)[2] <- "lowmove"
levels(SAT$noise_action)[3] <- "highjump"
levels(SAT$noise_action)[4] <- "highmove"

SAT[ , c(3)]<- as.factor(SAT[ , c(3)])

names(SAT)[names(SAT) == 'value'] <- 'RT1'

# descriptives 
descr_RT1_highjump <- describeBy(SAT$RT1[SAT$noise_action == 'highjump'], SAT$group[SAT$noise_action == 'highjump'])
descr_RT1_highmove<- describeBy(SAT$RT1[SAT$noise_action == 'highmove'], SAT$group[SAT$noise_action == 'highmove'])
descr_RT1_lowjump <- describeBy(SAT$RT1[SAT$noise_action == 'lowjump'], SAT$group[SAT$noise_action == 'lowjump'])
descr_RT1_lowmove <- describeBy(SAT$RT1[SAT$noise_action == 'lowmove'], SAT$group[SAT$noise_action == 'lowmove'])

descr_RT1_highjump <- ldply (descr_RT1_highjump, data.frame)
descr_RT1_highmove <- ldply (descr_RT1_highmove, data.frame)
descr_RT1_lowjump <-  ldply (descr_RT1_lowjump, data.frame)
descr_RT1_lowmove <-  ldply (descr_RT1_lowmove, data.frame)

descr_RT1 <- rbind(descr_RT1_highjump, descr_RT1_lowjump,descr_RT1_highmove, descr_RT1_lowmove)
descr_RT1[1,15] = "highjump"
descr_RT1[2,15] = "highjump"
descr_RT1[3,15] = "lowjump"
descr_RT1[4,15] = "lowjump"
descr_RT1[5,15] = "highmove"
descr_RT1[6,15] = "highmove"
descr_RT1[7,15] = "lowmove"
descr_RT1[8,15] = "lowmove"

names(descr_RT1)[names(descr_RT1) == 'V15'] <- 'noise_action'
names(descr_RT1)[names(descr_RT1) == '.id'] <- 'group'

#checking for assumptions #####
subOA <- subset(B3_SAT, group == "OA")
subYA <- subset(B3_SAT, group == "YA")

#### normality: Shapiro-Test #####
SAT %>%
  group_by(noise_action, group) %>%
  shapiro_test(RT1) 

#### homoscedasticity: Levene-Test ####
SAT %>%
  group_by(group) %>%
  levene_test(RT1 ~ noise_action) # variances are equal

subYAlong <- subset(SAT, group == "young adults")
subOAlong <- subset(SAT, group == "older adults")


#plotting ####
# plot bar plot with error bars (standard error of the mean)
#design jitter for data points
jitter = position_jitterdodge(
  jitter.width = 0.09,
  dodge.width = 0.7,
  seed = NA
)

#define colors
SAT <- SAT %>% 
  mutate(Color = ifelse(SAT$noise_action == "high", "#CCCCCC",
                        ifelse(SAT$noise_action == "low", "#999999", "none")))

ggplot(descr_RT1, aes(x=group, y=mean, fill=noise_action)) + 
  geom_bar(stat="identity", width=0.7, position=position_dodge(), 
           aes(fill = noise_action), color="black", size=0.2, alpha = 0.5) +
  geom_point(data = SAT, position = jitter, size = 1.5, aes(y = RT1, x = group,color="darkgrey")) +
  scale_color_identity() +
  geom_errorbar(aes(ymin=mean-se, ymax=mean+se), width=.2,  size = 0.6, position=position_dodge(.7)) +
  
  theme(
    axis.title.y = element_text(hjust=0.5, size = 15),
    axis.text.y = element_text(face = "bold", size = 15), 
    axis.line = element_line(),
    axis.ticks.x = element_blank(),
    title = element_text(face = "bold", size = 10),
    axis.title.x = element_blank(),  
    axis.text.x = element_blank(),   
    panel.background = element_rect(fill = "white"),
    panel.border = element_rect(color = "black", fill = NA, size = 1)  
  ) +
  ylab("planning time (s)") +
  scale_y_continuous(limits = c(0, 10)) +
  coord_cartesian(ylim=c(6.7,10))

#analyses of noise x action x group effects ####
SAT <- subset(B3_SAT,select=c("group","participant_ID","balancing","mean_RT1_low_noise_jump","mean_RT1_low_noise_move","mean_RT1_high_noise_jump","mean_RT1_high_noise_move"))
SAT <-melt.data.frame(SAT, id=c("group", "participant_ID","balancing"), variable_name = "noise_action")
SAT <- SAT %>%
  mutate(
    noise = ifelse(grepl("high_noise", noise_action), "high", "low"))

SAT <- SAT %>%
  mutate(
    action = ifelse(grepl("jump", noise_action), "jump", "move"))

SAT[ , c(1)]<- as.factor(SAT[ , c(1)])
SAT[ , c(3)]<- as.factor(SAT[ , c(3)])
SAT[ , c(6)]<- as.factor(SAT[ , c(6)])
SAT[ , c(7)]<- as.factor(SAT[ , c(7)])

names(SAT)[names(SAT) == 'value'] <- 'RT1'

# Fit the ANOVA model
res <- anova_test(
  data = SAT, dv = RT1, wid = participant_ID,
  between = group, within = c(noise, action), effect.size = "ges", type = 3, detailed = TRUE)
get_anova_table(res, correction = "GG")

pwc <- SAT %>%
  group_by(action) %>%
  pairwise_t_test(
    RT1 ~ noise, paired = TRUE,
    p.adjust.method = "bonferroni"
  )
pwc

pwc2 <- SAT %>%
  group_by(noise) %>%
  pairwise_t_test(
    RT1 ~ action, paired = TRUE,
    p.adjust.method = "bonferroni"
  )
pwc2


